<?php

include ("Scenario.php");

$s = new Scenario(3,6,3);
$s->run();
?>